# Linux File Manager (lfm)

A lightweight, dependency-free Bash CLI for common project file management tasks on Linux.

## Features
- Initialize a managed directory with config and logs
- List files with filters (type, depth, human sizes)
- Search by name, glob, or regex
- Size & extension reports
- Archive to `.tar.gz` (with exclude patterns)
- Incremental backup using `rsync` (dry-run supported)
- Safe Trash/Restore flow (`~/.local/share/lfm/trash`)
- Simple content-based deduplication (SHA256)
- Operation audit logs
- Systemd timer for scheduled backups (optional)

## Quick start

```bash
# Install (creates /usr/local/bin/lfm)
sudo ./install.sh

# See help
lfm help

# Initialize management in a directory
lfm init /path/to/project

# List files
lfm list /path/to/project --type file --max-depth 2

# Find by pattern
lfm find /path/to/project --name "*.py"

# Size report
lfm report /path/to/project --by size

# Create archive
lfm archive /path/to/project --output /backups/project-$(date +%F).tar.gz --exclude "*.log"

# Backup via rsync
lfm backup /path/to/project --to /backups/project --dry-run

# Move to trash
lfm trash /path/to/project some/large_file.bin

# Restore from trash
lfm restore /path/to/project some/large_file.bin

# Deduplicate (dry-run by default)
lfm dedupe /path/to/project --apply

# View logs
lfm log /path/to/project
```

## Configuration

Default config path order (first wins):
1. `PROJECT/.lfm/lfm.conf`
2. `$XDG_CONFIG_HOME/lfm/config` or `~/.config/lfm/config`

Example keys in config:
```ini
# lfm.conf
[core]
trash_dir = ~/.local/share/lfm/trash
log_file = .lfm/lfm.log

[backup]
rsync_flags = -aHAX --delete --info=stats1,progress2
exclude = .git,.lfm,*.tmp,*.swp
```

## Systemd (optional)

```bash
# Edit systemd files if needed
sudo cp systemd/lfm-backup.service /etc/systemd/system/
sudo cp systemd/lfm-backup.timer /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now lfm-backup.timer
```

## Uninstall

```bash
sudo ./uninstall.sh
```

---
**Note:** The tool aims to be safe by default (dry-runs, trash instead of rm). Always review flags before applying changes on critical data.
